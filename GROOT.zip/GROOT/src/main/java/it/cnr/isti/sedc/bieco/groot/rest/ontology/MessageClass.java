package it.cnr.isti.sedc.bieco.groot.rest.ontology;

public enum MessageClass {
	communication, control, status, data, request, log, response;
}
